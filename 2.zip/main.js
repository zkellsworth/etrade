
const todoStyle = {
    border:'0px solid blue',
    width: '30%',
    margin: 'auto',
    marginTop: '1em'
}

Vue.component('todo-input',{
    props: {
        value:{
            type: String,
            default: ''       
        }
    },
    template: `<v-text-field
     :hint="hint"
     :placeholder="placeholder"
     :style="styleObject"
     :append-icon="todoicon"
     :rounded="bRounded"
     :solo="bSolo"
     v-on:change="inputFinalized"
     :value="value"
     v-on:input="inputChanged($event)"

     ></v-text-field>`,
    data: function () {
        return{
            styleObject: todoStyle,
            hint: "type something and press enter",
            placeholder: 'new item',
            todoicon: 'mdi-pencil',
            bRounded: true,
            bSolo: true,
        }
    },
    methods: {

        inputChanged: function(strvalue) {
            this.$emit('input', strvalue)
        },

        inputFinalized: function (strvalue) {
            this.$emit('input', "")
        }
    }
})

new Vue({
    el: '#app',
    vuetify: new Vuetify(),
    data:{
        inputvalue: ''

    }
  })



//https://css-tricks.com/making-the-move-from-jquery-to-vue/
//https://css-tricks.com/snippets/css/a-guide-to-flexbox/
