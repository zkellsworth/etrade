
var sidebarApp = new Vue({
    el: '#sidebar',
    data:{
        message: 'Sidebar Item by Vue!'
    }
})

var titleBar = new Vue({
    el: '#titlebar',
    asyncData:{
        teststring: 'mytest'
    },
    mounted(){
        this.height = "2000";
    },
})

Vue.component('button-counter',{
    data: function(){
        return{
            count: 0
        }
    },
    template: '<button v-on:click="count++"> You clicked me {{ count }} times.</button>'
})

new Vue({
    el: '#components-demo'
})