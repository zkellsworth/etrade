


var item1 ={
    id: 1,
    title: 'AAPL',
    text: `Symbol is apple 1 `
}

var item2 ={
    id: 2,
    title: 'MSFT',
    text: `Symbol is apple 2 `
}

var item3 ={
    id: 3,
    title: 'GOOG',
    text: `Symbol is apple 3 `
}

var item4 ={
    id: 4,
    title: 'AMZN',
    text: `Symbol is apple 4`
} 

var myVisibleList = [item1, item2, item3, item4]


Vue.component('todo-item',{
    props: ['goal'],
    template: `
        <v-expansion-panel>
            <v-expansion-panel-header>{{goal.title}}</v-expansion-panel-header>
            <v-expansion-panel-content>
                {{ goal.details }}
            </v-expansion-panel-content>
        </v-expansion-panel>
    ` 
})


Vue.component('card-list',{
    props: ['goals'],
    template: `
        <v-expansion-panels>
            <todo-item v-for="goal in goals" :key="goal.title" v-bind:goal="goal" ></todo-item>
        </v-expansion-panels>
    `
})

new Vue({
    el: '#app',
    vuetify: new Vuetify(),
    data:{
        database: virtual_database
    }
  })



//https://css-tricks.com/making-the-move-from-jquery-to-vue/
//https://css-tricks.com/snippets/css/a-guide-to-flexbox/
