
var introduction = {
    title: 'Neuroburst',
    details: `There are a number of things I need to do in order to make my goals. Arnold Schwartznegger once said, make your goals big.`
}

var goal1 = {
    title: 'Time Bisection',
    details: `I want to build a website that will allow you to bisect time. It will be ad supported. I'll essentially scrape a bunch of data from 
    wikipedia drop it into a simple sqlite database, add social media sharing stuff on it. I'll also make an android app version that is ad supported`
}

var goal2 = {
    title: `Karina's School thing`,
    details: `This project is potentially worth millions.`
}

var goal3 = {
    title: `Machine Learning using Neural Networks`,
    details: `I need this for analizing data from nerve imputs.`
}

var goal4 = {
    title: `Machine Learning using linear regression`,
    details: `I need this for analizing data from nerve imputs.`
}

var goal5 = {
    title: `Mathematics: Algebra`,
    details: `I need this for analizing data from nerve imputs.`
}

var goal6 = {
    title: `Mathematics: Geometry`,
    details: `I need this for analizing data from nerve imputs.`
}

var goal7 = {
    title: `Mathematics: Calculus`,
    details: `I need this for analizing data from nerve imputs.`
}

var goal8 = {
    title: `Mathematics: Linear Algebra`,
    details: `I need this for analizing data from nerve imputs.`
}

var goal9 = {
    title: `Tradebot`,
    details: `I'll use my machine learning to build a simple trade bot`
}

var goal10 = {
    title: `Electronics`,
    details: `I want to build a robotic arm that looks like alita's doll body arm`
}

var goal11 = {
    title: `School`,
    details: `I need schooling`
}

var goal12 = {
    title: `Bioengineering/Computational Neuroscience`,
    details: `I need to find out how to highjack the brain`
}

var virtual_database = {
    goals:[
        introduction,
        goal1,
        goal2,
        goal3,
        goal4,
        goal5,
        goal6,
        goal7,
        goal8,
        goal9,
        goal10,
        goal11,
        goal12,
    ]
}